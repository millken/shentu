

function on_accept(player, quest_id)
	lualib:DelBuff(player, "��ʥ֮��")
    return true
end
