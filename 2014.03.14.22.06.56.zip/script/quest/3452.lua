
function on_accept(player, quest_id)
	lualib:SetInt(player, "3452_q", 0)
	lualib:SetInt(player, "3452", 5)--5ΪҪ����ɽ�ħ����Ĵ���
    
	local e = lualib:IO_GetCustomVarInt("daily_count"..player)
	if e >= 5 then
		lualib:SetInt(player, "3452_q", 1)
		local u = e - 5
		lualib:IO_SetCustomVarInt("daily_count"..player, u)	
	end		
	
	return true
end


function can_accomplish(player, quest_id)
	local a = lualib:GetInt(player, "3452_q")
	if a ~= 1 then
		return false
	end
	return true
end





