
	
--����ɹ���ȡ�ص�
--quest_id ����id

function on_accept(player, quest_id)
	lualib:SetInt(player, "3453_q", 0)	
	
	return true
end

function can_accomplish(player, quest_id)
	local a = lualib:GetInt(player, "3453_q")
	if a ~= 1 then
		return false
	end
	return true
end
