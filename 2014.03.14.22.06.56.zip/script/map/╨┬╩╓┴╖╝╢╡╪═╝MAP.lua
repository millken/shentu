local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function on_map_create(map)
	lualib:Map_GenMonster(map, 38, 47, 20, 3, "����¹", 25, false)
	lualib:Map_GenMonster(map, 38, 47, 20, 3, "���ֵ�����", 25, false)
	lualib:Map_GenMonster(map, 38, 47, 20, 3, "���ְ�����", 25, false)
	lualib:AddTrigger(map, lua_trigger_enter_map, "on_enter_map")
	lualib:AddTrigger(map, lua_trigger_leave_map, "on_leave_map")
end
function on_enter_map(player)
	lualib:AddTimer(player, lualib:GenTimerId(player), 1000, -1, "xs_paodian_time")
end

function on_leave_map(player)

end

function xs_paodian_time(player, timer_id)
	local map_name = "����������ͼ"
	local map = lualib:MapGuid(player)
	local map_key_name = lualib:KeyName(map)
	local exps = 5
	if map_name ~= map_key_name then
		lualib:DisableTimer(player, timer_id)
	else
		lualib:Player_AddExp(player, exps, "���ֵ�ͼ�ݵ��ȡ����", "����������ͼMAP")
	end
end