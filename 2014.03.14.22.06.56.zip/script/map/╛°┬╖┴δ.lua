local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

local jln_bx_npc_gen_times = 1000 * 9000
local jln_bx_npc_gen_count = 1
local jln_bx_npc_gen_name = "��·�뱦��"
local jln_bx_npc_guid = {}

function on_map_create(map_code)

	--ˢ�¾�·�뱦��NPC
	for i = 1, jln_bx_npc_gen_count do
		--jln_bx_npc_guid[i] = lualib:Map_GenNpc(map_code, jln_bx_npc_gen_name, 95, 223, 5, 3)
		jln_bx_npc_guid[i] = lualib:Map_GenNpcRnd(map_code, jln_bx_npc_gen_name)
        lualib:Print("��·�뱦�䣺[x,y] = ["..lualib:Npc_GetPosX(jln_bx_npc_guid[i])
                    ..", "..lualib:Npc_GetPosY(jln_bx_npc_guid[i]).."]")
	end
	
	--��·�뱦��NPC��ʱ��
	local ret = lualib:AddTimer(map_code,  lua_jln_map_bx_npc_timer, jln_bx_npc_gen_times, -1, "on_timer")
	if ret == false then
        lualib:Print("��·�뱦��ˢ�¶�ʱ������ʧ�ܣ�")
		return
	end
    lualib:Print("��·�뱦��ˢ�¶�ʱ�����ӳɹ���")
end

function on_map_destroy()
	local ret = lualib:Map_SetOffTimer(map_code,  lua_jln_map_bx_npc_timer)
	if ret == false then
		return
	end
end

function on_enter_map(player) 
    
end


function on_leave_map(player)
    
end

function on_item_appear(item_guid, item_id, x, y)
    
end

function on_item_disappear(item_guid, item_id, x, y)
    
end

function on_monster_appear(monster_guid, monster_id, x, y)
    
end

function on_monster_disappear(monster_guid, monster_id, x, y)
    
end

function on_npc_appear(npc_guid, npc_id, x, y)
    
end

function on_npc_disappear(npc_guid, npc_id, x, y)
    
end

function on_monster_attack(monster, actor)
    
end

function on_monster_post_die(monster, killer)
    
end

--��ͼ��ʱ���ص�����
function on_timer(mapcode, timer_id)
	
	--����NPC��ʱ���ص�
	if timer_id ==  lua_jln_map_bx_npc_timer then
		
		--���NPC���ڣ�������ԭ��NPC������ˢ��
		for i = 1, jln_bx_npc_gen_count do
			if jln_bx_npc_guid[i] ~= nil and lualib:Npc_IsExist(jln_bx_npc_guid[i]) then
				lualib:Npc_Remove(jln_bx_npc_guid[i])
			end
			--jln_bx_npc_guid[i] = lualib:Map_GenNpc(mapcode, jln_bx_npc_gen_name, 95, 223, 5, 3)
			jln_bx_npc_guid[i] = lualib:Map_GenNpcRnd(mapcode, jln_bx_npc_gen_name)
            lualib:Print("��·�뱦�䣺[x,y] = ["..lualib:Npc_GetPosX(jln_bx_npc_guid[i])
                        ..", "..lualib:Npc_GetPosY(jln_bx_npc_guid[i]).."]")
		end	
		lualib:SysMsg_SendMapMsg(mapcode, "Ѱ������ʿ�ǣ���·�뱦��ˢ���ˣ�")
	end
end
