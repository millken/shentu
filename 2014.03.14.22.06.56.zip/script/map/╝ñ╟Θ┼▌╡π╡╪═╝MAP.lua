local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function on_map_create(map)
	lualib:AddTrigger(map, lua_trigger_enter_map, "on_enter_map")
end

function on_enter_map(player)
	lualib:RunClientScript(player, "ItemEffect", "texiao", "100002840#32#42#0#99999000")
	lualib:RunClientScript(player, "ItemEffect", "texiao", "100002840#28#42#0#99999000")
	lualib:RunClientScript(player, "ItemEffect", "texiao", "100002840#32#48#0#99999000")
	lualib:RunClientScript(player, "ItemEffect", "texiao", "100002840#28#48#0#99999000")
	lualib:RunClientScript(player, "ItemEffect", "texiao", "100002840#30#45#0#99999000")
	lualib:RunClientScript(player, "ItemEffect", "texiao", "200001017#30#45#0#99999000")
end


