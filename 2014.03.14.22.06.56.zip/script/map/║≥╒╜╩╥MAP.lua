local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function on_map_create(map)
	lualib:AddTrigger(map, lua_trigger_enter_map, "on_enter_map")
end

function on_enter_map(player)
	lualib:AddTimer(player, lualib:GenTimerId(player), 15000, 1, "xs_paodian_time")
end

function xs_paodian_time(player, timer_id)
	local map = lualib:MapGuid(player)
	if lualib:Name(map) ~= "��ս��" then
		return
	end
	
	local map = lualib:Map_GetMapGuid("����")
	local dgn = lualib:GetStr(map, "jqmngc_dgn2")
	
	if lualib:Player_SetDgnTicket(player, dgn) == false then
		return "����ʧ�ܣ�"
    end

    if lualib:Player_EnterDgn(player, "���Ǹ���", 288, 254, 3) == false then
		return "����ʧ�ܣ�"
    end
end