local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function main(player, item)

	local item_guid = lualib:Player_GetEquipGuid(player,  lua_site_weapon)
	if item_guid == "" then
		return false
	end
	
	local result = lualib:Player_FixSingleEquip(player, item_guid, false)
	if result == false then
		return false
	end
	
	return true

end

function on_create(item)
--	lualib:AddTimerEx(item, 1, 500, 1, "tip", "")
	
end

function tip(item)
	local item_name = lualib:Name(item)
	local item_map_guid = lualib:MapGuid(item)
	local item_map_name = lualib:Name(item_map_guid)
	local item_map_x = lualib:X(item)
	local item_map_y = lualib:Y(item)
	local item_role = lualib:ItemRole(item)
	local player_name = lualib:Name(item_role)
	
	if item_map_x < 20000 then

	else	
		return
	end
end