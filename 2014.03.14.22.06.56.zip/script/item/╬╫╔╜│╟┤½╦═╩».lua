function main(player_guid, item_guid)
    --lualib:RunClientScript(csmapguid, "mapeffect", "texiao", "100001671#237#303#0#0")
    return lualib:Player_MapMoveXY(player_guid, "��ɽ��", 237, 303, 3)
end
