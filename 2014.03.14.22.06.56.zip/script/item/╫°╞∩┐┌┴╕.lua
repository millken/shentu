local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")
require("system/horse")

function main(player, item)
    local horse = lualib:Item_GetBySite(player,  lua_site_mount)
    if horse == "" then
		lualib:SysMsg_SendTriggerMsg(player, "û��װ������")
        return false
    end
    
    --��ǰ�;�
    local durability = lualib:Item_GetDurability(player, horse)

    --�;�����
    local max_durability = lualib:Item_GetMaxDurability(player, horse)

    --lualib:SysMsg_SendTriggerMsg(player, "durability = "..durability.." max_durability = "..max_durability)
            
    if durability == 0 then
		lualib:SysMsg_SendTriggerMsg(player, "��ǰ�����Ѿ�����,����ʹ��[���ﻹ�굤]����")
        return false
    end
    
    if durability == max_durability then
		lualib:SysMsg_SendTriggerMsg(player, "��ǰ����ܱ���")
        return false
    end
    
    --�������;�ֵ
    local addtion = 2000
    
    local new_durability = durability + addtion
    if new_durability > max_durability then
        new_durability = max_durability
    end
    
    lualib:Item_SetDurability(player, horse, new_durability)
    lualib:SysMsg_SendTriggerMsg(player, "������˿���")
    local amount = lualib:Item_GetAmount(player, item)
    lualib:Item_SetAmount(player, item, amount - 1)
        
    return true
end
