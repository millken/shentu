local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function main(player, item)
	local msg = ""
	if lualib:GetInt(player, "vip7_ssyao") == 1 then
		msg = msg.."���Ѿ�����һ�������̵꣬���Ժ�ʹ�ô˹��ܣ�\n \n"
		msg = msg.."<@exit *01*���뿪��>\n"
		lualib:NPCTalk(player, msg)
	    return false
	end	
	local mapkeya = {"��Ĺ", "����", "���ǻʹ�", "Ⱥħ����"}
	for i = 1, #mapkeya do
		if lualib:Player_GetStrProp(player, lua_role_current_map_key) == mapkeya[i] then
			msg = msg.."��ǰ��ͼ������ʹ�ô˹��ܣ����뿪�˵�ͼ����ʹ�ã�"
			lualib:NPCTalk(player, msg)
			return true
		end
	end

    local map = lualib:Player_GetGuidProp(player, lua_role_current_map_id)
    local player_x = lualib:X(player)
    local player_y = lualib:Y(player)
    local npc_guid = lualib:Map_GenNpc(map, "�����̵����Ա", player_x, player_y, 1, 3)
    if "" == npc_guid then
		msg = msg.."ʹ�������̵����ʧ��"
        return msg
    end
	
	lualib:SetStr(npc_guid, "vip7_player_guid", player)
	lualib:SetInt(player, "vip7_ssyao", 1)
	lualib:AddTimer(player, 812, 180000, 1, "dsssyaonpc_ssyao")
    return true
end

function dsssyaonpc_ssyao(player, timer_id)
	lualib:SetInt(player, "vip7_ssyao", 0)
	return true
end
	
function exit(player)
	return ""
end


function on_create(item)
	lualib:AddTimerEx(item, 1, 500, 1, "tip", "")
	
end

function tip(item)
	local item_name = lualib:Name(item)
	local item_map_guid = lualib:MapGuid(item)
	local item_map_name = lualib:Name(item_map_guid)
	local item_map_x = lualib:X(item)
	local item_map_y = lualib:Y(item)
	local item_role = lualib:ItemRole(item)
	local player_name = lualib:Name(item_role)
	
	if item_map_x < 20000 then

	else	
		return
	end
end
