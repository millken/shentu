local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function main(player, item)
	local PlayerLevel = lualib:Player_GetIntProp(player,  lua_role_level)
	local addExp = 900000
	if not lualib:Player_AddExp(player, addExp, "ʹ�þ��鵤", "ʹ�þ��鵤") then
		lualib:Print("���鵤ʹ��ʧ��")
		return false
	else
		lualib:Print("���鵤ʹ�óɹ�")
		return true
	end
end
