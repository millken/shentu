function main(player_guid, item_guid)
    return lualib:Player_MapMoveXY(player_guid, "����", 234, 222, 5)
end
