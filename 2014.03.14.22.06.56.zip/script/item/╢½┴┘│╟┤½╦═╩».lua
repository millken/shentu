function main(player_guid, item_guid)
    return lualib:Player_MapMoveXY(player_guid, "���ٳ�", 330, 300, 3)
end
