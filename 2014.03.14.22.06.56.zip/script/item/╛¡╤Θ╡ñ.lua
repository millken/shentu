local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function main(player, item)
	local level = lualib:Level(player)
	local exp = ((level)^3)/5+1
	if not lualib:Player_AddExp(player, exp, "ʹ�þ��鵤", "ʹ�þ��鵤") then
		lualib:Print("���鵤ʹ��ʧ��")
		return false
	end
	return true
end