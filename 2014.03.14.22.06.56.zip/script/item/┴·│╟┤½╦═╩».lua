local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")
function main(player_guid, item_guid)
    local csmapguid = lualib:Map_GetMapGuid("����")
    lualib:RunClientScript(csmapguid, "mapeffect", "texiao", "100001671#234#222#0#0")
    return lualib:Player_MapMoveXY(player_guid, "����", 234, 222, 5)
end