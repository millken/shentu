local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/online_gift")
require("system/��ֵ���")
require("system/��ȡ����")
require("system/ÿ��ǩ��")
require("system/��Ѩ̽��")
require("system/Ŀ��ϵͳ")
require("system/����")
require("system/ת��")
require("system/˫��������")
require("system/�ճ�")
require("system/�Զ����")
require("system/��ȡ���")

local all_timecount = 
{
    ["�������"] = { 
            complete = function(player)
                show_my_online_gift(player)            
            end,
            uncomplete = function(player)
                show_my_online_gift(player)            
            end,
        },
    ["��ֵ���"] = { 
            complete = function(player)
                show_my_first_bill_gift(player)            
            end,
            uncomplete = function(player)
                show_my_first_bill_gift(player)            
            end,
        },
    ["��ȡ����"] = { 
            complete = function(player)
               lingqujingyan(player)            
            end,
            uncomplete = function(player)
               lingqujingyan(player)
            end,
        },
    ["ÿ��ǩ��"] = { 
            complete = function(player)
				meiriqiandao(player)            
            end,
            uncomplete = function(player)
                meiriqiandao(player)
            end,
        },
		
    ["��Ѩ̽��"] = { 
            complete = function(player)
                tanbao(player)            
            end,
            uncomplete = function(player)
                tanbao(player)            
            end,
        },	
    ["Ŀ��ϵͳ"] = { 
            complete = function(player)
                mubiao(player)            
            end,
            uncomplete = function(player)
                mubiao(player)            
            end,
        },		
	["����"] = { 
            complete = function(player)
                gonglue(player)            
            end,
            uncomplete = function(player)
                gonglue(player)            
            end,
        },	
	["ת��ϵͳ"] = { 
            complete = function(player)
                zhuansheng(player)            
            end,
            uncomplete = function(player)
                zhuansheng(player)            
            end,
        },	
	["˫��������"] = { 
            complete = function(player)
                huanlesong(player)            
            end,
            uncomplete = function(player)
                huanlesong(player)            
            end,
        },
	["�ճ�"] = { 
            complete = function(player)
                richang(player)            
            end,
            uncomplete = function(player)
                richang(player)            
            end,
        },
	["�Զ����"] = { 
		complete = function(player)
                guaji(player)            
            end,
            uncomplete = function(player)
                guaji(player)            
            end,
        },		
    ["��ȡ���"] = { 
            complete = function(player)
                libao_dianji(player)            
            end,
            uncomplete = function(player)
                libao_dianji(player)            
            end,
        },				
		
}








function main(player, notify)
    local time = lualib:Player_GetCustomVarInt(player, notify.."����ʱ")

    if all_timecount[notify] ~= nil then
        if time > lualib:GetTime() then
            lualib:Print("����ʱδ��ɣ�����ύ����ʱ"..notify);
            all_timecount[notify].uncomplete(player)
        else
            lualib:Print("����ʱ��ɣ�����ύ����ʱ"..notify);
            all_timecount[notify].complete(player)
        end
    end

    return ""
end
