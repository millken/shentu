function ShowTimeCount(player, time, icon, notify)
    local content = time.."\n"..icon.."\n"..notify
    lualib:Player_SetCustomVarInt(player, notify.."����ʱ", lualib:GetTime() + time)
    lualib:ShowFormWithContent(player, "����ʱ", content)
end

function ShowTimeCount2(player, time, icon, notify, xianshi, ziti)
    local content = time.."\n"..icon.."\n"..notify.."\n"..xianshi.."\n"..ziti
    lualib:Player_SetCustomVarInt(player, notify.."����ʱ", lualib:GetTime() + time)
    lualib:ShowFormWithContent(player, "����ʱ", content)
end