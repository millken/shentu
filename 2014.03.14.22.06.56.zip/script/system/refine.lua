local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

refine_valid_item_att = {
{ lua_role_max_phy_atk_pct,  lua_role_max_mag_atk_pct,  lua_role_max_tao_atk_pct},
{ lua_role_max_phy_def_pct,  lua_role_max_mag_def_pct},
{ lua_role_max_hp_pct,  lua_role_max_mp_pct},
{ lua_role_max_phy_def_pct,  lua_role_max_mag_def_pct},
{},
{ lua_role_max_phy_def_pct,  lua_role_max_mag_def_pct},
{},
{ lua_role_max_hp_pct,  lua_role_max_mp_pct},
{ lua_role_max_phy_atk_pct,  lua_role_max_mag_atk_pct,  lua_role_max_tao_atk_pct},
{},
{},
{},
{},
{ lua_role_max_hp_pct, lua_role_max_mp_pct},
}

refine_att_addtion = {
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
{1, 2, 3, 4, 6, 8, 11, 15, 19, 20, 20, 20, 20, 20, 20},
}


randAtt = {
                   --�ȼ���    {����ֵ1������ֵ2}��{}
				{"RefineAtt_level_1",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_2",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_3",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_4",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_5",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_6",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_7",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_8",  {0, 0, 0, 0}, {10000, 0, 0, 0}},
				{"RefineAtt_level_9",  {0, 0, 0, 0}, {10000, 0,  0, 0}},
				{"RefineAtt_level_10", {0, 0, 0, 0}, {10000, 0,  0, 0}},
				{"RefineAtt_level_11", {0, 0, 0, 0}, {10000, 0,  0, 0}},
				{"RefineAtt_level_12", {0, 0, 0, 0}, {10000,    0,  0, 0}},
				{"RefineAtt_level_13", {0, 0, 0, 0}, {10000,    0,  0, 0}},
				{"RefineAtt_level_14", {0, 0, 0, 0}, {10000,    0,  0, 0}},
				{"RefineAtt_level_15", {0, 0, 0, 0}, {10000,    0,     0,  0}},					
			}

function update_item(player, item, refine_next_level, att_name)
    local sub_type = lualib:Item_GetSubType(player, item)
	local refine_level = lualib:Equip_GetRefineLevel(player, item)
	if refine_next_level > refine_level then
		local a = math.random(1,10000)
		local key = 1
		for i = 1, #randAtt[refine_next_level][3] do
			if randAtt[refine_next_level][3][i] < a then
				key = i + 1
				break
			end
		end
		
		lualib:SetInt(item, "RefineAtt_level_"..refine_next_level, randAtt[refine_next_level][2][key])
	end
	
	
    if not lualib:Equip_SetRefineLevel(player, item, refine_next_level) then
        return false
    end

    local new_att_name = 0
    local new_attr_value = 0

    if refine_next_level > 0 then
        new_att_name = att_name
        new_attr_value = refine_att_addtion[sub_type][refine_next_level]
    end
	
	--���ֵ����
	local randAtt = 0

	for i = 1, refine_next_level do
		local strName = tostring("RefineAtt_level_"..i)
		local refine_rand =lualib:GetInt(item, strName)
		randAtt = randAtt + refine_rand
	end
	
    if not lualib:Equip_SetRefineProp(player, item, new_att_name, new_attr_value + randAtt) then
        return false
    end

    return true
end

--item: ������Ʒ new_refine_level: �����ȼ� att_name: ��������
function refine_item(player, item, new_refine_level, att_name)
    if lualib:Item_GetType(player, item) ~= 1 then
        return "����װ�����ɾ���"
    end

    local refine_level = lualib:Equip_GetRefineLevel(player, item)
    if refine_level >= 15 then
        return "�Ѿ�ǿ������ߵȼ�"
    end

    --refine_valid_item_att
    local sub_type = lualib:Item_GetSubType(player, item)
    local find = false
    for _, v in pairs(refine_valid_item_att[sub_type]) do
        if v == att_name then
            find = true
        end
    end

    if not find then
        return "װ������ǿ��������"
    end

    if not update_item(player, item, new_refine_level, att_name) then
        return "ϵͳ����"
    end

    lualib:Item_NotifyUpdate(player, item)
    lualib:OnGloryTrigger(player, lua_glory_trigger_jinglian, item, 0, "����", "")

    return ""
end