function main(npc,player)
	local msg = ""
	msg = msg .."     ��椻�����¸ң�\n \n"
	msg = msg.."#OFFSET<X:0,Y:0>##IMAGE1902700017##OFFSET<X:0,Y:0>#<@likai *01*�뿪��>\n"
	return msg
end

function likai(npc,player)
	return ""
end
