local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

local mons_name = "����"
local map = nil
local X = nil
local Y = nil

function on_create(monster)
	lualib:AddBuff(monster, "�䶷����������Ů", 0)
	map = lualib:MapGuid(monster)
	X = lualib:X(monster)
	Y = lualib:Y(monster)
	local monster_1 = lualib:Map_GenSingleMonster(map, X, Y, 2, 5, mons_name, false)
	local mons_name_1 = lualib:KeyName(monster_1)
	lualib:AddTimerEx(monster, 1, 120000, 1, "delete", "")
	lualib:AddTrigger(monster, lua_trigger_monster_disappear, "on_trigger_monster_disapper")
	lualib:AddTrigger(monster, lua_trigger_post_die, "on_trigger_monster_die")	

end

function delete(monster)
	lualib:Monster_Remove(monster)	
	lualib:DisableTimer(monster, 1)

end

function on_trigger_monster_disapper(monster)	
	local mons_table = lualib:Map_GetRegionMonsters(map, mons_name, X, Y, 20, false, true)

	lualib:Monster_Remove(mons_table[1])
	lualib:RemoveTrigger(monster, lua_trigger_monster_disappear, "on_trigger_monster_disapper")
	return true
end

function on_trigger_monster_die(monster)	
	local mons_table = lualib:Map_GetRegionMonsters(map, mons_name, X, Y, 20, false, true)	

	lualib:Monster_Remove(mons_table[1])
	lualib:RemoveTrigger(monster, lua_trigger_post_die, "on_trigger_monster_die")
	return true

end