local ysax_dgwf_xbxy_timer = 1
local destroy_monster = "on_timer_destroy_monster"
--local path_table = {}
--path_table["Ѱ��С��1"] = {181, 59, 337, 204, 171,282 ,144,209, 181, 59}
--path_table["Ѱ��С��2"] = {156, 274, 63, 171, 145, 32, 317, 245, 156, 274}
--path_table["Ѱ��С��3"] = {250, 57, 277, 255, 123, 327, 53, 109, 250, 57}
--path_table["Ѱ��С��4"] = {279, 240, 263, 61, 36, 42, 160, 302, 279, 240}
--path_table["Ѱ��С��5"] = {350, 161, 173, 318, 25, 205, 112, 85, 350, 161}

function on_create(monster)
    --local monster_name = lualib:Monster_GetKeyName(monster)
    --if monster_name == "" or path_table[monster_name] == nil then
        --lualib:Print("Ѱ·С��.lua Ѱ·С����û���ҵ���Ӧ�Ĺ�������")
        --return
    --end

	if lualib:AddTimer(monster, ysax_dgwf_xbxy_timer, 3600000, 1, destroy_monster) == false then
        lualib:Print("Ѱ·С��.lua �������ٶ�ʱ��ʧ�ܣ�") 
        return
    end
    
    --if lualib:Monster_SetSeeker(monster, path_table[monster_name], 1, true) == false then 
        --lualib:Print("Ѱ·С��.lua ��ΪѰ·��ʧ�ܣ�") 
        --return
    --end
end

function on_timer_destroy_monster(monster, player)
    if lualib:Monster_IsExist(monster) == false then return end
    lualib:Monster_Remove(monster)
end