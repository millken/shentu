local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function on_create(monster)
    lualib:AddTrigger(monster, lua_trigger_post_die, "on_trigger_post_die")
end

function on_trigger_post_die(actor, killer)
	local x = lualib:Monster_GetPosX(actor)
    local y = lualib:Monster_GetPosY(actor)
	local map = lualib:Monster_GetMap(actor)
	lualib:Map_GenItem(map, x, y, "�ڰ�֮��", 1, true, 1)
end