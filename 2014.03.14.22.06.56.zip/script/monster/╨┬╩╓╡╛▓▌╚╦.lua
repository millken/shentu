local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")

function on_create(monster)
    lualib:AddTrigger(monster,  lua_trigger_post_die, "on_died")
end

function on_died(actor, killer)
	if lualib:GenRandom(1, 4) == 2 then
		local x = lualib:X(actor)
		local y = lualib:Y(actor)
		lualib:Map_GenItem(lualib:MapGuid(actor), x, y, "1Ԫ��", 1, true, 1)
	end
	
	local map_xy_table = lualib:MapRndPos(lualib:KeyName(lualib:MapGuid(actor)))
	local map_x = map_xy_table["x"]
	local map_y = map_xy_table["y"]
	lualib:Map_GenMonster(lualib:MapGuid(actor), map_x, map_y, 1, 3, lualib:KeyName(actor), 1, false)
	lualib:ClearTrigger(actor)
end
