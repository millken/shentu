local lua_path = lualib:IO_GetLuaPath()
local package_path = package.path
package.path = string.format("%s;%s?.lua;%s?", package_path, lua_path, lua_path)
require("system/logic_def_lua")
require("system/horse")
--require("system/system")  �������û�б�Ҫ���պ��ڴ�

local glory_callback =
{
    [6] = --��һ�����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
		    if action == 6 and target_name=="����1�����" then
				local cur_use = lualib:Player_SetCustomVarInt(player, "item_use", 1);
			end
        end,

        check_complete = function(player)
			local cur_use = lualib:Player_GetCustomVarInt(player, "item_use");
			if cur_use == 1 then
			lualib:Player_SetCustomVarInt(player, "item_use", 0);
				return true
			end
				return false
        end,
    },

    [7] = --����é®
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {1,2,3,4,5,6}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 38)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾͳ���é®,��á�����é®���ĳƺ�")
					return true
        end,
    },

    [8] = --�ﵽʮ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 10 then
				return true
			end
				return false
        end,
    },

    [12] = --����������
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and (map_name == "����������" or map_name =="�м�������" or map_name =="�߼�������") then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [13] = --��̽��·��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and map_name=="��·��" then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_jueluling");
				lualib:Player_SetCustomVarInt(player, "kill_jueluling", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_jueluling");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_jueluling", 0);
				return true
			end
				return false
        end,
    },

    [14] = --��̽��·��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and map_name=="��·��" then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_juelugu");
				lualib:Player_SetCustomVarInt(player, "kill_juelugu", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_juelugu");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_juelugu", 0);
				return true
			end
				return false
        end,
    },

    [15] = --��̽����ڣ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="����ڣ1" or map_name=="����ڣ2" or map_name=="����ڣ3" or map_name=="����ڣboss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_jueluling");
				lualib:Player_SetCustomVarInt(player, "kill_jueluling", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_jueluling");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_jueluling", 0);
				return true
			end
				return false
        end,
    },

    [16] = --��ս������
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="������" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_kulouwang", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_kulouwang");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_kulouwang", 0);
				return true
			end
				return false
        end,
    },

    [17] = --С��ţ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {8,9,10,12,13,14,15,16}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 42)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾ�С��ţ��,��á�С��ţ�����ĳƺ�")
					return true
        end,
    },

    [18] = --�ﵽ��ʮ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 20 then
				return true
			end
				return false
        end,
    },

    [19] = --�����ħ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "��ħ��" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [24] = --��̽��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="������1" or map_name=="������2" or map_name=="������3" or map_name=="������4" or map_name=="������5" or map_name=="������6") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_kuangdong");
				lualib:Player_SetCustomVarInt(player, "kill_kuangdong", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_kuangdong");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_kuangdong", 0);
				return true
			end
				return false
        end,
    },

    [25] = --��̽��ɽ��Ѩ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="��ɽ��Ѩ1" or map_name=="��ɽ��Ѩ2" or map_name=="��ɽ��Ѩ3" or map_name=="��ɽ��Ѩ4" or map_name=="��ɽ��Ѩ5" or map_name=="��ɽ��Ѩ6" or map_name=="��ɽ��Ѩ7" or map_name=="��ɽ��Ѩ8" or map_name=="��ɽ��Ѩboss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_yaoshan");
				lualib:Player_SetCustomVarInt(player, "kill_yaoshan", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_yaoshan");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_yaoshan", 0);
				return true
			end
				return false
        end,
    },

    [26] = --��ս��ڤʬ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="��ڤʬ��" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_shiwang", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_shiwang");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_shiwang", 0);
				return true
			end
				return false
        end,
    },

    [27] = --��¶��â
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {18,19,20,21,23,24,25,26,60}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 39)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾͳ�¶��â,��á���¶��â���ĳƺ�")
					return true
        end,
    },

    [28] = --�ﵽ��ʮ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 30 then
				return true
			end
				return false
        end,
    },

    [29] = --������ħ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "��ħ��" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

--[[    [30] = --����������
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "������" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [31] = --�����������
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "�������" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [32] = --����������
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "���������ض�" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },
   ]]
    [33] = --�����Ĺ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "��Ĺ" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [37] = --��̽��·��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="��·��1" or map_name=="��·��2" or map_name=="��·��3" or map_name=="��·��boss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_juelucheng");
				lualib:Player_SetCustomVarInt(player, "kill_juelucheng", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_juelucheng");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_juelucheng", 0);
				return true
			end
				return false
        end,
    },

    [38] = --��̽�����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="�����1" or map_name=="�����2" or map_name=="�����3" or map_name=="�����4" or map_name=="�����5" or map_name=="�����6" or map_name=="�����boss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_tianhuangzhen");
				lualib:Player_SetCustomVarInt(player, "kill_tianhuangzhen", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_tianhuangzhen");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_tianhuangzhen", 0);
				return true
			end
				return false
        end,
    },

    [39] = --��̽���а��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="а��1" or map_name=="а��2" or map_name=="а��3" or map_name=="а��4" or map_name=="а��5" or map_name=="а��boss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_xiemiao");
				lualib:Player_SetCustomVarInt(player, "kill_xiemiao", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_xiemiao");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_xiemiao", 0);
				return true
			end
				return false
        end,
    },

    [40] = --���ܴ�ʦ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 5 and (target_name=="����ն4��" or target_name=="��������4��" or target_name=="��֮ͥ��4��") then
				local cur_learn = lualib:Player_SetCustomVarInt(player, "learn_skill", 1);
			end
        end,

        check_complete = function(player)
			local cur_learn = lualib:Player_GetCustomVarInt(player, "learn_skill");
			if cur_learn == 1 then
				lualib:Player_SetCustomVarInt(player, "learn_skill", 0);
				return true
			end
				return false
        end,
    },

    [41] = --��սţħ����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="ţħ����" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_kulouwang", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_kulouwang");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_kulouwang", 0);
				return true
			end
				return false
        end,
    },


    [42] = --�۳�ɳ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {28,29,30,31,32,33,34,35,36,37,38,39,40,41}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 37)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾͳ۳�ɳ��,��á��۳�ɳ�����ĳƺ�")
					return true
        end,
    },

    [43] = --�ﵽ��ʮ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 40 then
				return true
			end
				return false
        end,
    },

    [44] = --������ħ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "��ħ��" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [45] = --���׾���
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			local level = lualib:Equip_GetRefineLevel(player, target)
			if action == 1003 and level >= 4 then
				local cur_refine = lualib:Player_SetCustomVarInt(player, "refine_item", 1);
			end
        end,

        check_complete = function(player)
			local cur_refine = lualib:Player_GetCustomVarInt(player, "refine_item");
			if cur_refine == 1
			then
				lualib:Player_SetCustomVarInt(player, "refine_item", 0);
				return true
			end
				return false
        end,
    },

    [46] = --���׼���
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			local att_count = lualib:Equip_GetIdentifyNum(player, target)
			if action == 1004 and att_count >= 2 then
				local att_count = lualib:Player_SetCustomVarInt(player, "jianding_item", 1);
			end
        end,

        check_complete = function(player)
			local att_count = lualib:Player_GetCustomVarInt(player, "jianding_item");
			if att_count == 1
			then
				lualib:Player_SetCustomVarInt(player, "jianding_item", 0);
				return true
			end
				return false
        end,
    },

    [47] = --������װ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local suit_count = 0
			local suit_def =
			{
				[lua_site_helmet] = {["ĩ��ͷ��"] = true, ["Ѫҹħ��"] = true, ["��ٵ���"] = true},
				[lua_site_wrist_0] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_wrist_1] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_shoes] = {["ĩ��սѥ"] = true, ["Ѫҹħѥ"] = true, ["��ٵ�ѥ"] = true},
				[lua_site_necklace] = {["ĩ������"] = true, ["Ѫҹ����"] = true, ["�������"] = true},
				[lua_site_ring_0] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
				[lua_site_ring_1] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
			}

			for k, v in pairs(suit_def) do
				local item = lualib:Player_GetItemGuid(player, k)
				local keyname = lualib:KeyName(item)
				if v[keyname] == true then
					suit_count = suit_count + 1
				end
			end

			if suit_count >= 1 then
				return true
			end
				return false
        end,
    },

    [48] = --��װ�ռ�
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local suit_count = 0
			local suit_def =
			{
				[lua_site_helmet] = {["ĩ��ͷ��"] = true, ["Ѫҹħ��"] = true, ["��ٵ���"] = true},
				[lua_site_wrist_0] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_wrist_1] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_shoes] = {["ĩ��սѥ"] = true, ["Ѫҹħѥ"] = true, ["��ٵ�ѥ"] = true},
				[lua_site_necklace] = {["ĩ������"] = true, ["Ѫҹ����"] = true, ["�������"] = true},
				[lua_site_ring_0] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
				[lua_site_ring_1] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
			}

			for k, v in pairs(suit_def) do
				local item = lualib:Player_GetItemGuid(player, k)
				local keyname = lualib:KeyName(item)
				if v[keyname] == true then
					suit_count = suit_count + 1
				end
			end

			if suit_count >= 2 then
				return true
			end
				return false
        end,
    },

    [49] = --������װ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local suit_count = 0
			local suit_def =
			{
				[lua_site_helmet] = {["ĩ��ͷ��"] = true, ["Ѫҹħ��"] = true, ["��ٵ���"] = true},
				[lua_site_wrist_0] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_wrist_1] = {["ĩ�ջ���"] = true, ["Ѫҹ����"] = true, ["��ٻ���"] = true},
				[lua_site_shoes] = {["ĩ��սѥ"] = true, ["Ѫҹħѥ"] = true, ["��ٵ�ѥ"] = true},
				[lua_site_necklace] = {["ĩ������"] = true, ["Ѫҹ����"] = true, ["�������"] = true},
				[lua_site_ring_0] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
				[lua_site_ring_1] = {["ĩ�ս�ָ"] = true, ["Ѫҹħָ"] = true, ["��ٵ�ָ"] = true},
			}

			for k, v in pairs(suit_def) do
				local item = lualib:Player_GetItemGuid(player, k)
				local keyname = lualib:KeyName(item)
				if v[keyname] == true then
					suit_count = suit_count + 1
				end
			end

			if suit_count >= 5 then
				return true
			end
				return false
        end,
    },

    [50] = --��սǧ����ħ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="ǧ����ħ" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_qiannianshumo", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_qiannianshumo");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_qiannianshumo", 0);
				return true
			end
				return false
        end,
    },

    [51] = --��սѪ��ʦ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="Ѫ��ʦ" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_xuechanshi", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_xuechanshi");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_xuechanshi", 0);
				return true
			end
				return false
        end,
    },

    [52] = --��ս����ɮ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="����ɮ" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_fantianseng", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_fantianseng");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_fantianseng", 0);
				return true
			end
				return false
        end,
    },

    [53] = --������ҵ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {43,44,45,47,48,49,50,51,52}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 40)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾͽ�����ҵ,��á�������ҵ���ĳƺ�")
					return true
        end,
    },

    [54] = --�ﵽ��ʮ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 50 then
				return true
			end
				return false
        end,
    },

    [55] = --��ʦ����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			local level = lualib:Equip_GetRefineLevel(player, target)
			if action == 1003 and level >= 7 then
				local cur_refine = lualib:Player_SetCustomVarInt(player, "refine_item", 1);
			end
        end,

        check_complete = function(player)
			local cur_refine = lualib:Player_GetCustomVarInt(player, "refine_item");
			if cur_refine == 1
			then
				lualib:Player_SetCustomVarInt(player, "refine_item", 0);
				return true
			end
				return false
        end,
    },

    [56] = --��ʦ����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			local att_count = lualib:Equip_GetIdentifyNum(player, target)
			if action == 1004 and att_count >= 3 then
				local att_count = lualib:Player_SetCustomVarInt(player, "jianding_item", 1);
			end
        end,

        check_complete = function(player)
			local att_count = lualib:Player_GetCustomVarInt(player, "jianding_item");
			if att_count == 1
			then
				lualib:Player_SetCustomVarInt(player, "jianding_item", 0);
				return true
			end
				return false
        end,
    },

    [57] = --��̽��ħʯ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="��ħʯ��1" or map_name=="��ħʯ��2" or map_name=="��ħʯ��3" or map_name=="��ħʯ��4" or map_name=="��ħʯ��boss") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_tianmoshiku");
				lualib:Player_SetCustomVarInt(player, "kill_tianmoshiku", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_tianmoshiku");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_tianmoshiku", 0);
				return true
			end
				return false
        end,
    },

    [58] = --����������Ԩ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "������Ԩ1" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [59] = --��ս��ħ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and target_name=="��ħ��" then
				local cur_kills = lualib:Player_SetCustomVarInt(player, "kill_tianmoshen", 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_tianmoshen");
			if cur_kills == 1 then
				lualib:Player_SetCustomVarInt(player, "kill_tianmoshen", 0);
				return true
			end
				return false
        end,
    },

    [62] = --ѱ��ʦ
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local mountguid = lualib:Player_GetItemGuid(player, lua_site_mount);
			local horse_level = 0
			if mountguid ~= "" then
				horse_level = lualib:Item_GetCustomVarInt(player, mountguid, "h_level");
			end

			if horse_level >= 50 then
				return true
			end
				return false
        end,
    },

	
    [63] = --ǧ�����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)

			if action == lua_glory_trigger_horse_kaiguang then
				if ref_value == 5 then
					local aa = lualib:Player_SetCustomVarInt(player, "horse_top", 1);
				end
			end
			--lualib:Print("Ʒ��Ϊ:"..ref_value.."")
        end,

        check_complete = function(player)
			local aa = lualib:Player_GetCustomVarInt(player, "horse_top");
			if aa == 1 then
				lualib:Player_SetCustomVarInt(player, "horse_top", 0);
				return true
			end
				return false
        end,
    },

    [65] = --����Զ��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
				local all_glory = {54,55,57,58,59,61,62,63}
			for i = 1, table.getn(all_glory) do
				if lualib:GetPlayerGloryState(player, all_glory[i]) == 1 then
					return false
				end
			end
				lualib:AddTitle(player, 41)--�ɹ��������óƺ�
				lualib:SysMsg_SendWarnMsg(player, "��ϲ�����˳ɾ�����Զ��,��á�����Զ��ĳƺ�")
					return true
        end,
    },

    [66] = --������½1
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 2 then
				return true
			end
				return false
        end,
    },

    [67] = --������½2
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 3 then
				return true
			end
				return false
        end,
    },

    [68] = --������½3
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 4 then
				return true
			end
				return false
        end,
    },

    [69] = --������½4
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 5 then
				return true
			end
				return false
        end,
    },

    [70] = --������½5
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 6 then
				return true
			end
				return false
        end,
    },

    [71] = --������½6
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_login = lualib:Player_GetCustomVarInt(player, "login_days");
			if cur_login >= 7 then
				return true
			end
				return false
        end,
    },

    [72] = --��������1
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_onlinetime = lualib:OnlineTime(player);
			if cur_onlinetime >= 300 then
				return true
			end
				return false
        end,
    },

    [73] = --��������2
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_onlinetime = lualib:OnlineTime(player);
			if cur_onlinetime >= 900 then
				return true
			end
				return false
        end,
    },

    [74] = --��������3
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_onlinetime = lualib:OnlineTime(player);
			if cur_onlinetime >= 1800 then
				return true
			end
				return false
        end,
    },

    [75] = --��������4
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_onlinetime = lualib:OnlineTime(player);
			if cur_onlinetime >= 3600 then
				return true
			end
				return false
        end,
    },

    [76] = --��������5
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local cur_onlinetime = lualib:OnlineTime(player);
			if cur_onlinetime >= 7200 then
				return true
			end
				return false
        end,
    },

    [77] = --һ����;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 1 then
				return true
			end
				return false
        end,
    },

    [78] = --������;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 2 then
				return true
			end
				return false
        end,
    },

    [79] = --������;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 3 then
				return true
			end
				return false
        end,
    },

    [80] = --�ļ���;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 4 then
				return true
			end
				return false
        end,
    },

    [81] = --�弶��;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 5 then
				return true
			end
				return false
        end,
    },

    [82] = --������;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 6 then
				return true
			end
				return false
        end,
    },

    [83] = --�߼���;��Ա
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			local vip_level = lualib:GetVipLevel(player);
			if vip_level >= 7 then
				return true
			end
				return false
        end,
    },

    [84] = --���뺣���ؾ�
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 10 and map_name == "�������" then
				local cur_enters = lualib:Player_SetCustomVarInt(player, "map_enter", 1);
			end
        end,

        check_complete = function(player)
			local cur_enters = lualib:Player_GetCustomVarInt(player, "map_enter");
			if cur_enters == 1 then
				lualib:Player_SetCustomVarInt(player, "map_enter", 0);
				return true
			end
				return false
        end,
    },

    [85] = --��̽�ؾ�����
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
			if action == 2 and (map_name=="����1" or map_name=="����2" or map_name=="����3" or map_name=="����4" or map_name=="����5") then
				local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_haidi");
				lualib:Player_SetCustomVarInt(player, "kill_haidi", cur_kills + 1);
			end
        end,

        check_complete = function(player)
			local cur_kills = lualib:Player_GetCustomVarInt(player, "kill_haidi");
			if cur_kills >= 10 then
				lualib:Player_SetCustomVarInt(player, "kill_haidi", 0);
				return true
			end
				return false
        end,
    },
	
	    [86] = --��������10��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 10 then
				return true
			end
				return false
        end,
    },

	    [87] = --��������20��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 20 then
				return true
			end
				return false
        end,
    },
	
	    [88] = --��������30��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 30 then
				return true
			end
				return false
        end,
    },
	
	    [89] = --��������35��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 35 then
				return true
			end
				return false
        end,
    },
	
	    [90] = --��������36��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 36 then
				return true
			end
				return false
        end,
    },
	
	    [91] = --��������37��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 37 then
				return true
			end
				return false
        end,
    },
	
	    [92] = --��������38��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 38 then
				return true
			end
				return false
        end,
    },
	
	    [93] = --��������39��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 39 then
				return true
			end
				return false
        end,
    },
	
	    [94] = --��������40��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 40 then
				return true
			end
				return false
        end,
    },
	
	    [95] = --��������41��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 41 then
				return true
			end
				return false
        end,
    },
	
	    [96] = --��������42��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 42 then
				return true
			end
				return false
        end,
    },
	
	    [97] = --��������43��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 43 then
				return true
			end
				return false
        end,
    },
	
	    [98] = --��������44��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 44 then
				return true
			end
				return false
        end,
    },
	
	    [99] = --��������45��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 45 then
				return true
			end
				return false
        end,
    },
	
	    [100] = --��������46��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 46 then
				return true
			end
				return false
        end,
    },
	
	    [101] = --��������47��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 47 then
				return true
			end
				return false
        end,
    },
	
	    [102] = --��������48��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 48 then
				return true
			end
				return false
        end,
    },
	
	    [103] = --��������49��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 49 then
				return true
			end
				return false
        end,
    },
	
	    [104] = --��������50��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 50 then
				return true
			end
				return false
        end,
    },
	
	    [105] = --��������51��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 51 then
				return true
			end
				return false
        end,
    },
	
	    [106] = --��������52��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 52 then
				return true
			end
				return false
        end,
    },
	
	    [107] = --��������53��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 53 then
				return true
			end
				return false
        end,
    },
	
	    [108] = --��������54��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 54 then
				return true
			end
				return false
        end,
    },
	
	    [109] = --��������55��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 55 then
				return true
			end
				return false
        end,
    },
	
	    [110] = --��������56��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 56 then
				return true
			end
				return false
        end,
    },
	
	    [111] = --��������57��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 57 then
				return true
			end
				return false
        end,
    },
	
	    [112] = --��������58��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 58 then
				return true
			end
				return false
        end,
    },
	
	    [113] = --��������59��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 59 then
				return true
			end
				return false
        end,
    },
	
	    [114] = --��������60��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 60 then
				return true
			end
				return false
        end,
    },
	
	    [115] = --��������61��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 61 then
				return true
			end
				return false
        end,
    },
	
	    [116] = --��������62��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 62 then
				return true
			end
				return false
        end,
    },
	
	    [117] = --��������63��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 63 then
				return true
			end
				return false
        end,
    },
	
	    [118] = --��������64��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 64 then
				return true
			end
				return false
        end,
    },
	
	    [119] = --��������65��
    {
        on_trigger = function(player, action, target, ref_value, target_name, map_name)
        end,

        check_complete = function(player)
			if lualib:Level(player) >= 65 then
				return true
			end
				return false
        end,
    },
	
	
	
	
}

function OnTrigger(glory_id, player, action, target, ref_value, target_name, map_name)
    if glory_callback[glory_id] ~= nil and glory_callback[glory_id].on_trigger ~= nil then
        glory_callback[glory_id].on_trigger(player, action, target, ref_value, target_name, map_name)
    end
end

function CheckComplete(glory_id, player)
    if glory_callback[glory_id] == nil or glory_callback[glory_id].check_complete
	== nil then
        return true
    end

    return glory_callback[glory_id].check_complete(player)
end
